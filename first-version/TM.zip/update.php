<?php
include "shared/conn.php";
?>

<?php
include "shared/head.php";
?>
<div class="container">
   <div class="row">
      <div class="col-md-12">
		<div class="col-md-2">
		</div>

		<div class="col-md-8">
		
		<?php
		
		$id = $_POST["id"];
		$zh_CN = $_POST["zh_CN"];  
		$en_US = $_POST["en_US"];  
        
		
		mysqli_select_db($conn,"mytm"); //连接数据库
		
		mysqli_query($conn,"set names utf8"); //防止出现中文乱码的情况
			
		
		//$sql = "INSERT INTO stitm(zh_CN,en_US) VALUES('$zh_CN','$en_US')";  
		$sql = "UPDATE `stitm` SET `zh_CN` = '{$zh_CN}', `en_US` = '{$en_US}' ,WHERE `ID` = '{$id}'";
					
		$update = mysqli_query($conn,$sql);  
		
		if(!$update)  
			{  
				echo "<div class='alert alert-success'>无法更新翻译单元".mysqli_error($conn)."</div>";  
			}  
			else  
			{  
				echo "<div class='alert alert-success'>翻译单元更新成功！</div>";	
				echo "<a type='btn' class='btn btn-primary'href='index.php'>查看数据</a>";
			}  
		
		mysqli_close($conn);  
		?>
		</div>

		<div class="col-md-2">
		</div>		
	  
	  </div>
    
   </div>

</div>
<?php
include "shared/foot.php";
?>