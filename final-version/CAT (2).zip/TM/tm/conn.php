<?php
$conn=mysqli_connect('localhost','root','root','tm'); 
mysqli_query($conn,"set names utf8");
?>