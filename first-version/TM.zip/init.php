<?php
include "shared/conn.php";
?>

<?php
mysqli_select_db($conn,"mytm"); //连接数据库

mysqli_query($conn,"set names utf8"); //防止出现中文乱码的情况
      
$db_name = "mytm";
  
$sql_create_db = "

CREATE DATABASE {$db_name}
DEFAULT CHARACTER SET utf8
DEFAULT COLLATE utf8_general_ci

";  
               
$create_db = mysqli_query($conn,$sql_create_db);  
  
if(!$create_db)  
    {  
        echo "数据库".$db_name."创建失败: ".mysqli_error($conn);  
    }  
    else  
    {  
        echo "数据库".$db_name."创建成功！"."<br>";
		
		$table_name = "stitm";
		$sql_create_table = "
		
		CREATE TABLE `{$db_name}`.`{$table_name}`
		(  
		`ID` INT(5) NOT NULL AUTO_INCREMENT ,  
		`zh_CN` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,   
		`en_US` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,   
		`pos` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,   
		`usage` VARCHAR(300) CHARACTER SET utf8 COLLATE utf8_general_ci NULL ,  
		PRIMARY KEY (`ID`)  
		)   
		ENGINE = InnoDB   
		CHARSET=utf8   
		COLLATE utf8_general_ci; 		
		
		";
		
		$create_table = mysqli_query($conn,$sql_create_table);  
		
		if(!$create_table)   
		{  
			echo "数据表".$table_name."创建失败: ".mysqli_error($conn);  
		} 
		else{
			echo "数据表".$table_name."创建成功！"."<br>";
		}
	}
mysqli_close($conn);  
?>