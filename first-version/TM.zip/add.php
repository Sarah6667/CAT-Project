<?php
include "shared/conn.php";
?>
<?php 
$zh_CN = $_POST["zh_CN"];  
$en_US = $_POST["en_US"];   
$usage = $_POST["usage"];  

mysqli_select_db($conn,"mytm"); //连接数据库

mysqli_query($conn,"set names utf8"); //防止出现中文乱码的情况
      
  
$sql = "INSERT INTO stitm(zh_CN,en_US,usage) VALUES('$zh_CN','$en_US','$usage')";  
               
$insert = mysqli_query($conn,$sql);  
  
if(!$insert)  
    {  
        echo "无法插入翻译单元: ".mysqli_error($conn);  
    }  
    else  
    {  
        echo "翻译单元插入成功！"."<br>"; 
		echo "<a href='index.php'>查看数据</a>";
    }  

mysqli_close($conn);  
?>