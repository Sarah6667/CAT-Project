<?php
include "shared/head.php";
?>

<div class="container">
   <div class="row">
      <div class="col-md-12">
		<div class="col-md-2">
		</div>

		<div class="col-md-8">
			<form method="POST" action="add.php" > 
				<div class="input-group">
					<span class="input-group-addon">中文</span>
					<input type="text" class="form-control" name="zh_CN" >
				</div>					
				<br>
				<div class="input-group">
					<span class="input-group-addon">英文</span>
					<input type="text" class="form-control" name="en_US">
				</div>	
				<br>				
				<div class="input-group">
					<button class="btn btn-primary" type="submit">提交</button>
				</div>					
			</form>		
		</div>

		<div class="col-md-2">
		</div>		
	  
	  </div>
    
   </div>

</div>		


<?php
include "shared/foot.php";
?>