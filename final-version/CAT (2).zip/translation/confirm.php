<?php
session_start();


$target=$_POST["target"];

$comment=$_POST["comment"];

$conn=mysqli_connect('localhost','root','root','trans');

$sql="insert into translation(target,comment) values('$target','$comment') ";


mysqli_query($conn,$sql);

mysqli_close($conn);

echo "<a href='txttrans.php'>跳转回翻译页</a>";
?>