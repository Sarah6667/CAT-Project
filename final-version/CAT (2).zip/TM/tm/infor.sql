INSERT INTO `infor` VALUES (26, 19, '中文', 'Chinese');
INSERT INTO `infor` VALUES (25, 22, '我是ABC。', 'My name is ABC. ');
INSERT INTO `infor` VALUES (31, 19, '狗', 'dog');
INSERT INTO `infor` VALUES (30, 19, '猫', 'cat');
