<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!-- 新 Bootstrap 核心 CSS 文件 -->
<link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
 
<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
 
<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>

<title>STITM</title>
</head>
<body>

<nav class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
    <div class="navbar-header">
        <a class="navbar-brand" href="index.php">MyTM</a>
    </div>
    <div>
        <ul class="nav navbar-nav">
            <li><a href="index.php">主页</a></li>
            <li><a href="search.php">搜索</a></li>
            <li><a href="form.php">新增</a></li>

        </ul>
    </div>
    </div>
</nav>