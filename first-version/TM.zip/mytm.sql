-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2019-03-29 05:37:46
-- 服务器版本： 10.1.38-MariaDB
-- PHP 版本： 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `mytm`
--

-- --------------------------------------------------------

--
-- 表的结构 `stitm`
--

CREATE TABLE `stitm` (
  `ID` int(5) NOT NULL,
  `zh_CN` varchar(50) DEFAULT NULL,
  `en_US` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `stitm`
--

INSERT INTO `stitm` (`ID`, `zh_CN`, `en_US`) VALUES
(1, '我是第一句话。\n', 'I am the first sentence.\n'),
(2, '我是第二句话。\n', 'I am the second sentence.\n'),
(3, '我是第三句话。\n', 'I am the third sentence.\n'),
(4, '我是第四句话。\n', 'I am the fourth sentence.\n'),
(5, '我是第五句话。', 'I am the fifth sentence.');

--
-- 转储表的索引
--

--
-- 表的索引 `stitm`
--
ALTER TABLE `stitm`
  ADD PRIMARY KEY (`ID`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `stitm`
--
ALTER TABLE `stitm`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
