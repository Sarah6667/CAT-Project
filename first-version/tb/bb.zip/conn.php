<?php
$conn=mysqli_connect('localhost','root','','base'); 
mysqli_query($conn,"set names utf8");
?>