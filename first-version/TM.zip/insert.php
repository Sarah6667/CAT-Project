<?php
include "shared/conn.php";
?>

<?php
include "shared/head.php";
?>

<?php
   
   mysqli_select_db($conn,"mytm"); //连接数据库
   
   mysqli_query($conn,"set names utf8"); //防止出现中文乱码的情况
   
   
   
   $xml = simplexml_load_file("Demo.tmx"); //从TMX文件中读取数据，存入$xml变量

    $json = json_encode($xml); //将$xml中的数据转换为JSON格式

    $array = json_decode($json,true); //将JSON格式转换为PHP数组

    foreach($array["body"]["tu"] as $tu)
    
    {
        
        $zh = $tu["tuv"][0]["seg"];
        
        $en = $tu["tuv"][1]["seg"];
        
        $insert_sql = "INSERT INTO `stitm` (`zh_CN`, `en_US`) VALUES ('{$zh}', '{$en}')";
        
        $status = mysqli_query($conn,$insert_sql);
        
        if(!$status)
        {
            echo "数据导入失败！！";
        }
        else
        {
            echo "数据导入成功！！";
        }

    }
  
 
?>

<?php
include "shared/foot.php";
?>