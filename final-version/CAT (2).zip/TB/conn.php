<?php
$conn=mysqli_connect('localhost','root','root','tb'); 
mysqli_query($conn,"set names utf8");
?>